#include <iostream>
#include <thread>
#include <chrono>

const int NUM_THREADS = 10;
int shared_variable = 0;

void adder() {
    for (int i = 0; i < 1000; ++i) {
        shared_variable += 1;
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}

void subtractor() {
    for (int i = 0; i < 1000; ++i) {
        shared_variable -= 1;
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}

int main() {
    std::thread threads[NUM_THREADS];
    for (int i = 0; i < NUM_THREADS; ++i) {
        if (i % 2 == 0) {
            threads[i] = std::thread(adder);
        } else {
            threads[i] = std::thread(subtractor);
        }
    }
    for (int i = 0; i < NUM_THREADS; ++i) {
        threads[i].join();
    }
    std::cout << "Final value of shared variable: " << shared_variable << std::endl;
    return 0;
}