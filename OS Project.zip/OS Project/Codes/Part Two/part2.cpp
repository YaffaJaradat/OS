 #include<iostream>
#include<fstream>
#include<vector>
#include<iomanip>
#include<algorithm>
using namespace std;
struct process {
	int id;
	int vecivalTime;
	int cpuBurst;
	int proccesSize;
	int turnedArounedTime;
	int waitingTime;
	int finishTime;
};
struct quant {
	int pid;
	int time;
};
// the frame in physical memory
struct frame {
	//int pid;
	int frameNum;
	int frameUsed;
};
int randomGeneratours(vector<int>& avframe) {

	int genindex = rand() % avframe.size();
	int result = avframe[genindex];
	avframe.erase(avframe.begin() + genindex);
	return result;
}

bool compareFirst(process a, process b) {
	//give true if process a vecived before process b
	//to help sorting based on vecival time 
	if (a.vecivalTime < b.vecivalTime)
		return true;
	else return false;
}







int main() {
	ifstream fin;
	fin.open("./process.txt");
	int memorySize;
	int pageSize;
	int q;
	int cs;
	vector<process> vec;//vecay of struct that have the processes states (process)
	fin >> memorySize;
	fin >> pageSize;
	fin >> q;
	fin >> cs;
	while (!fin.eof()) {
		process p;
		fin >> p.id >> p.vecivalTime >> p.cpuBurst >> p.proccesSize;
		vec.push_back(p);
	}
	vector<quant> v;
	vector<process>tempvec;




	int frameNum = memorySize / pageSize;
	// this is litrally the physical memory 
	vector<frame>physicalMemory(frameNum);
	vector<int>AvailableFrames(frameNum);
	for (int i = 0; i < frameNum; i++) {
		AvailableFrames[i] = i;
	}



	// here we are creating the page table for each proccess
	// we can create vector of vector but here we want to create five seperate vectors for the process
	// here we are depending on the indexing of the vecay not hte process id when it comes on pagetablep*
	//  int innerfreg; we will add this if thet innerfreg is possible at 
	// declaring proccess table for all the processes

	sort(vec.begin(), vec.end(), compareFirst);//sort processes based on vecival time 
	vector<vector<int>>pageTable(vec.size());
	for (int i = 0; i < vec.size(); i++)
	{
		vector<int>v;
		pageTable[i] = v;
	}
	// first process " vec index 0 "
	// random generatour
	int vailableSize = memorySize;
	for (int i = 0; i < vec.size(); i++)
	{
		if (vec[i].proccesSize <= vailableSize) {
			int framenum = vec[i].proccesSize / pageSize;
			for (int j = 0; j < framenum; j++)
			{
				int f = randomGeneratours(AvailableFrames);
				pageTable[i].push_back(f);

			}
			vailableSize -= vec[i].proccesSize;
		}

		else {
			continue;
		}
	}
	for (int i = 0; i < physicalMemory.size(); i++) {
		physicalMemory[i].frameNum = -1;
	}
	cout << "| Process ID | Page Number | Frame Number" << endl << left;
	for (int i = 0; i < pageTable.size(); i++) {
		if (pageTable[i].size() == 0) {
			cout << "| " << setw(10) << vec[i].id << " | " << setw(11) << "No space" << " | " << "No space" << endl;
		}
		else {
			for (int j = 0; j < pageTable[i].size(); j++) {
				cout << "| " << setw(10) << vec[i].id << " | " << setw(11) << j << " | " << pageTable[i][j] << endl;
				physicalMemory[pageTable[i][j]].frameNum = vec[i].id;
			}
		}
	}
	cout << endl;
	cout << "Memory Map:" << endl << endl;
	for (int i = 0; i < physicalMemory.size(); i++) {
		if (physicalMemory[i].frameNum == -1) {
			cout << "| Empty";
		}
		else {
			cout << "| " << physicalMemory[i].frameNum << " ";
		}
	}
	cout << " |" << endl;
	int logicalAddr, prid;
	cout << "Enter PID: ";
	cin >> prid;
	cout << "Enter Logical Address: ";

	cin >> logicalAddr;
	while (logicalAddr > memorySize) {
		cout << "The size of the address you entered is invalid!" << endl;
		cout << "Please enter a new value: ";
		cin >> logicalAddr;
	}

	int i;
	for (i = 0; i < pageTable.size(); i++)
	{
		if (vec[i].id == prid) {
			break;
		}
	}
	if (pageTable[i].size() == 0) {
		cout << "The process with this id is not valid" << endl;
	}
	else {
		int pagenumber = logicalAddr / pageSize;
		int offset = logicalAddr % pageSize;
		int pyaddr = ((pageTable[i][pagenumber]) * (1 + pageSize)) + offset;
		cout << "Physical Address: " << pyaddr << endl;
	}
	system("pause");






	return 0;
}

