#include<iostream>
#include<string>
#include<fstream>
#include<iomanip>


using namespace std;

int memory, page, q, cs;

class PCB_C { 
public:
	int id;
	int arrival;
	int finish;
	int burst;
	int orgBurst;
	int size;

	PCB_C(int id, int arrival, int burst, int size) {  
		this->id = id;
		this->arrival = arrival;
		this->burst = burst;
		this->finish = arrival;
		this->orgBurst = burst;
	}
};

typedef PCB_C* PCB;

double avgBurst(PCB* arr, int n) {
	double value = 0;
	for (int i = 0; i < n; i++) {
		value += arr[i]->orgBurst;
	}
	return value / double(n);
}

double avgTurnaround(PCB* arr, int n) {
	double value = 0;
	for (int i = 0; i < n; i++) {
		value += (arr[i]->finish) - (arr[i]->arrival);
	}
	return value / double(n);
}

double avgWaiting(PCB* arr, int n) {
	double value = 0;
	for (int i = 0; i < n; i++) {
		value += ((arr[i]->finish - arr[i]->orgBurst) - arr[i]->arrival);
	}
	return value / double(n);
}

double CPUUtilization(PCB* arr, int n) {
	double flat = 0, highestEndTime = 0;
	for (int i = 0; i < n; i++) {
		flat += arr[i]->orgBurst;
	}
	for (int i = 0; i < n; i++) {
		if (arr[i]->finish > highestEndTime) highestEndTime = arr[i]->finish;
	}
	return (flat / highestEndTime) * 100.0;
}

void sortByArrival(PCB* arr, int n) {  
	int i, j;
	bool swapped;
	for (i = 0; i < n - 1; i++) {
		swapped = false;
		for (j = 0; j < n - i - 1; j++) {
			if (arr[j]->arrival > arr[j + 1]->arrival) {
				swap(arr[j], arr[j + 1]);
				swapped = true;
			}
		}

		
		if (swapped == false)
			break;
	}
}


void sortByBurst(PCB* arr, int n) {
	int i, j;
	bool swapped;
	for (i = 0; i < n - 1; i++) {
		swapped = false;
		for (j = 0; j < n - i - 1; j++) {
			if (arr[j]->orgBurst > arr[j + 1]->orgBurst) {
				swap(arr[j], arr[j + 1]);
				swapped = true;
			}
		}

		if (swapped == false)
			break;
	}
}



int LeastArrival(PCB* arr, int n) {  
	int value = arr[0]->arrival;
	for (int i = 1; i < n; i++) {
		if (arr[i]->arrival < value) value = arr[i]->arrival;
	}
	return value;
}

PCB* addItemToArray(PCB* arr, int& n, PCB item) {  
	PCB* narr = new PCB[n + 1];  
	for (int i = 0; i < n; i++) {  
		narr[i] = arr[i];
	}
	narr[n++] = item;  
	return narr;
}

PCB* removeItemToArray(PCB* arr, int& n, int index) {    
	PCB* narr = new PCB[n - 1];
	int counter = 0;
	for (int i = 0; i < n; i++) {
		if (i == index) continue;
		narr[counter++] = arr[i];
	}
	n--;
	return narr;
}

void RoundRobin(PCB* arr, int n) {
	cout << "RoundRobin:"<<endl;
	int an = 0;
	PCB* aarr = new PCB[an];  
	sortByArrival(arr, n);
	int start = 0;  
	int end = 0;  
	while (n > 0) {  
		bool found = false;  
		for (int i = 0; i < n; i++) {  
			PCB p = arr[i];
			if (p->arrival <= end) {   
				int processed = q;   
				if (p->burst < q) {  
					q = p->burst;  
				}
				cout << "| P(" << p->id << ") " << processed << " ";
				//				start = end;
				end += processed;
				p->burst -= processed;
				arr = removeItemToArray(arr, n, i);  
				if (p->burst > 0) {
					arr = addItemToArray(arr, n, p);  
				}
				else {
					aarr = addItemToArray(aarr, an, p);  
				}
				if (n >= 1) {  
					cout << "| CS: " << to_string(cs) << " ";
					end += cs;
				}
				found = true;
				break;
			}
		}
		if (!found) {  
			cout << "| Idle: " + to_string(LeastArrival(arr, n) - end) << " ";
			end = LeastArrival(arr, n);
		}
	}
	cout << endl<<endl;
	cout << "id" << "\t" << "   arival time" << "\t" << "   cpu burst" << "\t"
		<< "waiting time" << "\t" << "turned arouned time" << "\t" << "   finish time" << endl;
	for (int i = 0; i < an; i++)
		cout << aarr[i]->id << "\t\t" << aarr[i]->arrival
		<< "\t\t" << aarr[i]->orgBurst
		<< "\t\t" << ((aarr[i]->finish - aarr[i]->orgBurst) - aarr[i]->arrival)
		<< "\t\t" << (aarr[i]->finish - aarr[i]->arrival)
		<< "\t\t\t" << aarr[i]->finish << endl;

	cout << endl << endl;
	cout << "CPU UTLIZATION:" << CPUUtilization(aarr, an) << endl;
	cout << "Avg waiting: " << avgWaiting(aarr, an) << endl;
	cout << "Avg burst: " << avgBurst(aarr, an) << endl;
	cout << "Avg turnaround: " << avgTurnaround(aarr, an) << endl;
	
	cout << endl << "_______________________________________________________________________________________________________________________________________________________________________" << endl;
}

void shortJobFirst(PCB* arr, int n) {
	cout << "Short Job First:" << endl;
	int nn = 0;
	PCB* narr = new PCB[nn];
	sortByBurst(arr, n);
	int end = 0;
	while (n > 0) {
		bool found = false;  
		for (int i = 0; i < n; i++) {  
			if (arr[i]->arrival > end) continue;  
			arr[i]->finish = end + arr[i]->burst;  
			end += arr[i]->burst + cs;  
			cout << "| P(" << arr[i]->id << ") " << arr[i]->burst << " ";
			if (n > 1) {  
				cout << "| " << cs << " ";
				end += cs;
			}
			narr = addItemToArray(narr, nn, arr[i]);  
			arr = removeItemToArray(arr, n, i);     
			found = true;
			break;
		}
		if (!found) {  
			cout << "| Idle: " << (LeastArrival(arr, n) - end) << " ";
			end += LeastArrival(arr, n);
		}
	}
	cout << endl << endl;
	cout << "CPU UTLIZATION:" << CPUUtilization(narr, nn) << endl;
	cout << "Avg waiting: " << avgWaiting(narr, nn) << endl;
	cout << "Avg burst: " << avgBurst(narr, nn) << endl;
	cout << "Avg turnaround: " << avgTurnaround(narr, nn) << endl;
	cout << "id" << "\t" << "   arival time" << "\t" << "   cpu burst" << "\t"
		<< "waiting time" << "\t" << "turned arouned time" << "\t" << "   finish time" << endl;
	for (int i = 0; i < nn; i++)
		cout << narr[i]->id << "\t\t" << narr[i]->arrival
		<< "\t\t" << narr[i]->burst
		<< "\t\t" << ((narr[i]->finish - narr[i]->burst) - narr[i]->arrival)
		<< "\t\t" << (narr[i]->finish - narr[i]->arrival)
		<< "\t\t\t" << narr[i]->finish << endl;
	cout << endl << "_______________________________________________________________________________________________________________________________________________________________________" << endl;
}

void firstComeFirstServie(PCB* arr, int n) {
	cout << "First Come First Servie: " << endl;
	sortByArrival(arr, n);
	int end = 0;
	for (int i = 0; i < n; i++) {   
		PCB& p = arr[i];
		if (p->arrival > end) {   
			cout << "| Idle: " << (p->arrival - end) << " ";
			end = p->arrival;
		}
		cout << "| P(" << p->id << ") " << p->burst << " ";
		p->finish = end + p->burst;  
		end += p->burst;  
		if (i < n - 1) {   
			cout << "| " << cs << " ";
			end += cs;
		}
	}
	cout << endl << endl;
	cout << "CPU UTLIZATION:" << CPUUtilization(arr, n) << endl;
	cout << "Avg waiting: " << avgWaiting(arr, n) << endl;
	cout << "Avg burst: " << avgBurst(arr, n) << endl;
	cout << "Avg turnaround: " << avgTurnaround(arr, n) << endl;
	cout << "id" << "\t" << "   arival time" << "\t" << "   cpu burst" << "\t"
		<< "waiting time" << "\t" << "turned arouned time" << "\t" << "   finish time" << endl;
	for (int i = 0; i < n; i++)
		cout << arr[i]->id << "\t\t" << arr[i]->arrival
		<< "\t\t" << arr[i]->burst
		<< "\t\t" << ((arr[i]->finish - arr[i]->burst) - arr[i]->arrival)
		<< "\t\t" << (arr[i]->finish - arr[i]->arrival)
		<< "\t\t\t" << arr[i]->finish << endl;
	cout << endl << "_______________________________________________________________________________________________________________________________________________________________________" << endl;
}

int main() {
	ifstream ifs("./process.txt");
	ifs >> memory >> page >> q >> cs;
	int n = 0;
	PCB* arr = new PCB[n];
	while (ifs.eof() == false) {
		int id;
		int arrival;
		int burst;
		int size;
		ifs >> id >> arrival >> burst >> size;
		PCB_C* item = new PCB_C(id, arrival, burst, size);
		arr = addItemToArray(arr, n, item);
	}
	firstComeFirstServie(arr, n);
	cout << endl << endl << endl;
	shortJobFirst(arr, n);
	cout << endl << endl << endl;
	RoundRobin(arr, n);
	cout << endl << endl << endl;
	return 0;
}